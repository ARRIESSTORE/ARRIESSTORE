const chalk = require("chalk")
const fs = require("fs")

global.ownerNumber = ["6288220574267@s.whatsapp.net"]
global.nomerOwner = "6288220574267"
global.nomorOwner = ['6285732230674']
global.namaDeveloper = "AISS IMUT"
global.namaBot = "AISS IMUT"
global.packname = ""
global.author = "Sticker By AISS IMUT"
global.thumb = fs.readFileSync("./thumb.jpg")

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})

/*

Thanks To By ADITYA STORE JB
Di Tulis Dan Di Fix Oleh ADITYA STORE JB
Ubah Nomor Owner?
Ganti Di File ./owner.json

*/